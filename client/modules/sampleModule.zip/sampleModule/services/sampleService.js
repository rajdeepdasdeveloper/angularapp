sampleModule.service('sampleService', function() {
    this._Fn = function () {
        return;
    }
});