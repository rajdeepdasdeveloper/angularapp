sampleModule.directive("sampleDirective", function() {
    return {
       templateUrl : "",
	   controller: ""
    };
});

/* <sample-Directive></sample-Directive> */