sampleModule.factory('sampleFactory', function() {

    var factory = {}; 

    factory._Fn = function() {
		
	}

    return factory;
});