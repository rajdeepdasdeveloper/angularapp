var sampleModule = angular.module('', ['ui.router']);

sampleModule.controller('', function($scope, /* $http, $location, $state, $stateParams, feUserRegister_Factory, $parse */){
	
	var ctrl = this;
	
});