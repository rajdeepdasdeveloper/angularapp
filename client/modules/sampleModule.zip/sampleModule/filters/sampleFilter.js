sampleModule.filter("sampleFilter", function(){
			
	return function(){
		
	}
			
});